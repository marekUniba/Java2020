package solution;
public interface DvaDInterface { // v tomto module nic nepotrebuje riesit, takze ho nemente
	public double obsah();
	public double obvod();
	public boolean jeV(Bod2D b);
	public void posun(Bod2D b);
}
