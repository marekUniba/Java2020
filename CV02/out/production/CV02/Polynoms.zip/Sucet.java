public class Sucet extends Polynom {
    public Sucet(Polynom a, Polynom b) {}
    @Override
    Double valueAt(String[] vars, double[] values) { return null; };
    @Override
    Polynom derive(String var) { return null; };
}
