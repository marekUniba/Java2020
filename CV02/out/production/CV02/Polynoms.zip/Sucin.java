public class Sucin extends Polynom  {
    public Sucin(Polynom a, Polynom b) {}

    @Override
    Double valueAt(String[] vars, double[] values) { return null; };
    @Override
    Polynom derive(String var) { return null; };
}
