public class Konstanta extends Polynom {
    public Konstanta(double k) {}
    @Override
    Double valueAt(String[] vars, double[] values) { return null; };
    @Override
    Polynom derive(String var) { return null; };
}
