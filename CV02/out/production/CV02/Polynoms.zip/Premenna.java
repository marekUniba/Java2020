public class Premenna extends Polynom {
    public Premenna(String s) {}

    @Override
    Double valueAt(String[] vars, double[] values) { return null; };
    @Override
    Polynom derive(String var) { return null; };
}
